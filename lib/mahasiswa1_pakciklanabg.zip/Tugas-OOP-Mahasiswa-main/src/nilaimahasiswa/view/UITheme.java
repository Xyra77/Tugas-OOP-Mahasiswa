package nilaimahasiswa.view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;

/**
 * Tema UI — Dark Slate + Emerald
 * @author Pakcik Lanabg
 */
public class UITheme {

    // === Palette: Dark Slate + Emerald ===
    public static final Color SIDEBAR         = new Color(15, 23, 35);      // hampir hitam
    public static final Color SIDEBAR_HOVER   = new Color(30, 45, 62);      // hover sidebar
    public static final Color PRIMARY         = new Color(16, 185, 129);    // emerald
    public static final Color PRIMARY_DARK    = new Color(5, 150, 105);     // emerald dark
    public static final Color BACKGROUND      = new Color(18, 27, 40);      // bg gelap utama
    public static final Color CARD            = new Color(26, 38, 55);      // kartu gelap
    public static final Color TEXT_DARK       = new Color(226, 232, 240);   // teks utama terang
    public static final Color TEXT_MUTED      = new Color(100, 116, 139);   // teks redup
    public static final Color DANGER          = new Color(239, 68, 68);     // merah
    public static final Color SUCCESS         = new Color(16, 185, 129);    // emerald
    public static final Color BORDER          = new Color(40, 58, 80);      // border card

    public static final Font FONT_TITLE    = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_LABEL    = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_BUTTON   = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_NAV      = new Font("Segoe UI", Font.PLAIN, 14);

    public static void styleButtonPrimer(JButton btn) {
        btn.setBackground(PRIMARY);
        btn.setForeground(Color.WHITE);
        btn.setFont(FONT_BUTTON);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    public static void styleButtonOutline(JButton btn, Color warna) {
        btn.setBackground(CARD);
        btn.setForeground(warna);
        btn.setFont(FONT_BUTTON);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(warna, 1, true));
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    public static void styleTable(JTable table) {
        table.setRowHeight(28);
        table.setFont(FONT_LABEL);
        table.setBackground(CARD);
        table.setForeground(TEXT_DARK);
        table.setSelectionBackground(new Color(16, 185, 129, 60));
        table.setSelectionForeground(TEXT_DARK);
        table.setGridColor(BORDER);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_BUTTON);
        header.setBackground(new Color(15, 23, 35));
        header.setForeground(PRIMARY);
        header.setPreferredSize(new Dimension(0, 32));
    }

    public static void styleTable(JTable table, int... bobotKolom) {
        styleTable(table);
        javax.swing.table.TableColumnModel cm = table.getColumnModel();
        int total = 0;
        for (int b : bobotKolom) total += b;
        if (total <= 0 || cm.getColumnCount() != bobotKolom.length) return;
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        for (int i = 0; i < bobotKolom.length; i++) {
            int width = Math.round(600f * bobotKolom[i] / total);
            cm.getColumn(i).setPreferredWidth(width);
        }
    }
}
