package nilaimahasiswa.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Koneksi ke MySQL via JDBC.
 * Setiap pemanggilan getConnection() membuat koneksi baru
 * yang akan di-close otomatis lewat try-with-resources di DAO.
 *
 * @author Pakcik Lanabg
 */
public class DatabaseConnection {

    private static final String URL      = "jdbc:mysql://localhost:3306/db_nilai_mahasiswa";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    /** Mencegah instansiasi dari luar. */
    private DatabaseConnection() {}

    /**
     * Buat dan kembalikan koneksi baru ke database.
     * Caller wajib menutupnya (gunakan try-with-resources).
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
